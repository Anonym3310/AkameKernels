# AnyKernel3 Ramdisk Mod Script
# osm0sis @ xda-developers

## AnyKernel setup
# begin properties
properties() { '
kernel.string=
do.devicecheck=0
do.modules=1
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=maguro
device.name2=toro
device.name3=toroplus
device.name4=tuna
device.name5=
supported.versions=
supported.patchlevels=
'; } # end properties

# shell variables
block=$(find /dev -name boot | head -n 1);
is_slot_device=0;
ramdisk_compression=auto;


## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. tools/ak3-core.sh;


## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
set_perm_recursive 0 0 755 644 $ramdisk/*;
set_perm_recursive 0 0 750 750 $ramdisk/init* $ramdisk/sbin;


## AnyKernel install
dump_boot;

write_boot;

#fix error on boot 

ui_print " "
ui_print " Mounting system and vendor"
ui_print " "
mount -o rw,remount /system
mount -o rw,remount /vendor
mount -o rw,remount /

ui_print " "
ui_print "Backuping /system/build.prop to /system/build.prop.bak"
ui_print " "

cp /system/build.prop /system/build.prop.bak

ui_print " "
ui_print "Change value in /system/build.prop for fix error on device boot"
ui_print " "

sed -i 's/ro.treble.enabled=true/ro.treble.enabled=false/g' /system/build.prop


#cp fw files


cp -rf modules/vendor/firmware/* /$(find /vendor -name firmware | head -n 1);


#mkdir

mkdir -p /lib/modules/$(uname -r)

#install help magisk module & other

ui_print "Installing Magisk Module for Automaticly Activate (insmod) All Modules (*.ko-files) at Start Your Android"

cp -rf AutoInsmodModules /data/adb/modules

z(){
UNAME=$(ls /tmp/anykernel/modules/system/lib/modules/)

if
	test -d /data/local/nhsystem
then
	if
		test -d /data/local/nhsystem/kali-armhf
	then
		NH_PATH=/data/local/nhsystem/kali-armhf
	else
		NH_PATH=/data/local/nhsystem/kali-arm64
	fi
	mkdir -p $NH_PATH/lib/modules/
	cp -rf /tmp/anykernel/modules/system/lib/modules/$UNAME $NH_PATH/lib/modules/
	chmod 777 -R $NH_PATH/lib/modules/$UNAME
else
	sleep 0
fi

}

## end install


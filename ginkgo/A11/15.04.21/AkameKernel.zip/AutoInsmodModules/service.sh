#!/system/bin/sh


for mod in $(find /system/ -name *.ko)
do insmod $mod
done

for mod2 in $(find /vendor/ -name *.ko)
do insmod $mod2
done
